import React, { useEffect, useState } from 'react'
import '../Styles/Task.css'
import axios from 'axios';

//https://rickandmortyapi.com/api

const Task = () => {



    const [data, setData] = useState([]);
    
    

    useEffect(() => {
        axios.get('https://rickandmortyapi.com/api/character')
            .then(response => {
                setData(response.data.results)
            })
            .catch(error => console.log('fetching error', error))
    }, [])

    let handleFilter = (element) =>{
        const filtering = data.filter((x)=>x.name.includes(element))
        
    }
    


    return (
        <div>
            <div className='d-flex'>
                <div>
                    <input type="text" value={item} onChange={(e) => setItem(e.target.value)} />
                </div>
                <button onClick={''}></button>

                <input type="submit" />

                {item.length < 1 ?

                    null
                    :
                    <div>

                        <div>
                            <select name="" id="">
                                <option value="">Alive</option>
                                <option value="">Dead</option>
                                <option value="">Unknown</option>
                            </select>
                        </div>

                        <div>
                            <div>
                                <input type="radio" />
                                <span>Male</span>
                            </div>
                            <div>
                                <input type="radio" />
                                <span>Female</span>
                            </div>
                            <div>
                                <input type="radio" />
                                <span>Genderless</span>
                            </div>
                            <div>
                                <input type="radio" />
                                <span>Unknown</span>
                            </div>
                        </div>
                    </div>
                }
            </div>
            <div className='main-part'>
                {data.map((x) => (
                    <div className='card-section d-flex'>


                        <div className='main'>
                            <div>
                                <img src={x.image} alt="" />
                            </div>
                            <div>
                                <div className='second'>
                                    <h1>{x.name}</h1>
                                    <p>{x.status}</p>
                                    <p></p>
                                </div>
                                <div className='third'>
                                    <p>Last known location:</p>
                                    <p>{x.location.name}</p>
                                </div>
                                <div>
                                    <p>First seen in:</p>
                                    <p>{x.origin.name}</p>
                                </div>

                            </div>
                        </div>


                    </div>
                ))}

            </div>
        </div>
    )
}

export default Task
