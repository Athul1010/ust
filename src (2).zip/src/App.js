import './App.css';
import Task from './Components/Task';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Task/>
    </div>
  );
}

export default App;
